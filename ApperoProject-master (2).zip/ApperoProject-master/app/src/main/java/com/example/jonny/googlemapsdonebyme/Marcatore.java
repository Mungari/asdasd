package com.example.jonny.googlemapsdonebyme;

public class Marcatore {

    String id;
    String lat, lon, link;

    public Marcatore(String id, String lat, String lon, String link) {
        this.id = id;
        this.lat = lat;
        this.lon = lon;
        this.link = link;
    }
}
